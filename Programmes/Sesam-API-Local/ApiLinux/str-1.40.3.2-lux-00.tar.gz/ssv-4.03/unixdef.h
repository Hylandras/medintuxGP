/*
 * -------------------------------------------------------------------
 * (c) 2003 GIE SESAM-VITALE
 *
 * FICHIER : unixdef.h (v1)
 *
 * PLATE-FORME : UNIX
 *
 * D�finitions d�pendantes du syst�me.
 * -------------------------------------------------------------------
 */

#ifndef __UNIXDEF_H__
#define __UNIXDEF_H__

#ifndef API_ENTRY
#define API_ENTRY
#endif

#ifndef FARPTR
#define FARPTR *
#endif

/* Activation des fonctions simplifi�es. */
#ifndef SGD
#define SGD
#endif

#endif
